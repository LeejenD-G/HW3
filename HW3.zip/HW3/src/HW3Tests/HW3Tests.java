package HW3Tests;

import application.Students;
import application.Answers;

/**
 * This class automatically tests the Students and Answers class functionality.
 * It contains several tests for storing, displaying, and removing questions and answers.
 */
public class HW3Tests {
    
    /**
     * The main method that runs the tests.
     * 
     * @param args Command line arguments (not used).
     */
    public static void main(String[] args) {
        testStoreStudents();
        testViewStudentQuestions();
        testRemoveStudentQuesByID();
        testStoreAnswer();
        testRemoveAnswer();
    }

    /**
     * Test the functionality of storing students' questions.
     * This test ensures that students' questions are correctly stored and displayed.
     */
    private static void testStoreStudents() {
        System.out.println("==== Testing StoreStudents ====");
        Students students = new Students();
        students.StoreStudents("What is Java?", "I need help with Java basics.", "Alice", 101);
        students.StoreStudents("How does OOP work?", "Explain OOP concepts.", "Bob", 102);
        System.out.println("Expected: Two questions stored.");
        students.ViewStudentQuestions();
        System.out.println();
    }

    /**
     * Test the functionality of viewing students' questions.
     * This test ensures that all stored questions are printed to the console.
     */
    private static void testViewStudentQuestions() {
        System.out.println("==== Testing ViewStudentQuestions ====");
        Students students = new Students();
        students.StoreStudents("What is Java?", "I need help with Java basics.", "Alice", 101);
        students.StoreStudents("How does OOP work?", "Explain OOP concepts.", "Bob", 102);
        students.ViewStudentQuestions();
        System.out.println();
    }

    /**
     * Test the functionality of removing student questions by ID.
     * This test verifies that a student can remove their own question,
     * and ensures that the removal process works as expected.
     */
    private static void testRemoveStudentQuesByID() {
        System.out.println("==== Testing RemoveStudentQuesByID ====");
        Students students = new Students();
        students.StoreStudents("What is Java?", "I need help with Java basics.", "Alice", 101);
        students.StoreStudents("How does OOP work?", "Explain OOP concepts.", "Bob", 102);
        
        System.out.println("Before removal:");
        students.ViewStudentQuestions();
        
        students.RemoveStudentQuesByID(101, "Alice");
        System.out.println("After removal:");
        students.ViewStudentQuestions();
        
        // Attempting to remove with the wrong user ID
        students.RemoveStudentQuesByID(102, "Alice"); // doesn't allow :p
        System.out.println();
    }

    /**
     * Test the functionality of storing answers to questions.
     * This test ensures that answers are correctly tied to specific questions
     * and that the answers are properly stored.
     */
    private static void testStoreAnswer() {
        System.out.println("==== Testing StoreAnswer ====");
        Answers answers = new Answers();
        answers.StoreAnswer("Java is a programming language.", "Charlie", 102);
        answers.StoreAnswer("OOP stands for Object-Oriented Programming.", "Dave", 102);
        System.out.println("Expected: Two answers stored.");
        answers.ViewAnswers();
        System.out.println();
    }

    /**
     * Test the functionality of removing answers.
     * This test ensures that an answer can be correctly removed,
     * and verifies that the process works as expected.
     */
    private static void testRemoveAnswer() {
        System.out.println("==== Testing RemoveAnswer ====");
        Answers answers = new Answers();
        answers.StoreAnswer("Java is a programming language.", "Charlie", 102);
        answers.StoreAnswer("OOP stands for Object-Oriented Programming.", "Dave", 102);
        
        System.out.println("Before removal:");
        answers.ViewAnswers();
        
        answers.RemoveAnswer(102, "Charlie");
        System.out.println("After removal:");
        answers.ViewAnswers();
        
        // Attempting to remove with the wrong user id
        answers.RemoveAnswer(102, "Eve"); // doesn't allow :p
        System.out.println();
    }
}
