package application;

/**
 * Represents a student question with a title, body, username, and unique ID.
 */
public class Student {
    private String quesTitle;
    private String quesBody;
    private String name;
    private int id;

    public Student(String quesTitle, String quesBody, String name, int id) {
        this.quesTitle = quesTitle;
        this.quesBody = quesBody;
        this.name = name;
        this.id = id;
    }

    public String getQuesTitle() {
        return quesTitle;
    }

    public void setQuestionTitle(String newTitle) {
        this.quesTitle = newTitle;
    }

    public String getQuesBody() {
        return quesBody;
    }

    public void setQuestionBody(String newBody) {
        this.quesBody = newBody;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Title: " + quesTitle + "\nBody: " + quesBody + "\nAsked by: " + name + "\nID: " + id;
    }
}
