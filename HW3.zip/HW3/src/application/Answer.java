package application;

/**
 * Represents an answer to a student question.
 */
public class Answer {
    private String response;
    private String author;
    private int questionID;

    public Answer(String response, String author, int questionID) {
        this.response = response;
        this.author = author;
        this.questionID = questionID;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String newResponse) {
        this.response = newResponse;
    }

    public String getAuthor() {
        return author;
    }

    public int getQuestionID() {
        return questionID;
    }

    @Override
    public String toString() {
        return "Answer: " + response + "\nBy: " + author + "\nQuestion ID: " + questionID;
    }
}
