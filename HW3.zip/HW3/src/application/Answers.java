package application;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * Manages answers to student questions.
 */
public class Answers {
    private ArrayList<Answer> ansList = new ArrayList<>();

    /**
     * Stores an answer tied to a question.
     */
    public void StoreAnswer(String response, String author, int questionID) {
        ansList.add(new Answer(response, author, questionID));
    }

    /**
     * Displays all answers.
     */
    public void ViewAnswers() {
        for (Answer ans : ansList) {
            System.out.println(ans);
        }
    }

    /**
     * Removes an answer by ID if the user owns it.
     */
    public void RemoveAnswer(int questionID, String author) {
        Iterator<Answer> iterator = ansList.iterator();
        while (iterator.hasNext()) {
            Answer ans = iterator.next();
            if (ans.getQuestionID() == questionID && ans.getAuthor().equals(author)) {
                iterator.remove();
                System.out.println("Answer removed successfully.");
                return;
            }
        }
        System.out.println("Error: you do not have permission to remove this answer.");
    }
}
