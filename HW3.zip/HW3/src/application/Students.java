package application;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * Manages student questions by allowing storage, retrieval, and deletion.
 */
public class Students {
    private ArrayList<Student> stuList = new ArrayList<>();

    /**
     * Stores a student question into the list.
     */
    public void StoreStudents(String questionTitle, String questionBody, String username, int ID) {
        stuList.add(new Student(questionTitle, questionBody, username, ID));
    }

    /**
     * Displays all student questions.
     */
    public void ViewStudentQuestions() {
        for (Student stu : stuList) {
            System.out.println(stu);
        }
    }

    /**
     * Removes a student question by ID if the user owns it.
     */
    public void RemoveStudentQuesByID(int ID, String user) {
        Iterator<Student> iterator = stuList.iterator();
        while (iterator.hasNext()) {
            Student stu = iterator.next();
            if (stu.getId() == ID && stu.getName().equals(user)) {
                iterator.remove();
                System.out.println("Question removed successfully.");
                return;
            }
        }
        System.out.println("Error: you do not have permission to remove this question.");
    }
}
